
document.addEventListener('DOMContentLoaded', function () {
    const colorPicker = document.getElementById('colorPicker');
    const selectedColor = document.getElementById('selectedColor');
    const colorDisplay = document.getElementById('colorDisplay');

    colorPicker.addEventListener('input', function () {
        const color = colorPicker.value;
        selectedColor.textContent = color;
        colorDisplay.style.backgroundColor = color;
    });
});
